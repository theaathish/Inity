#!/bin/bash
# Inity installer for macOS
# Developed by Aathish at Strucureo

echo "Installing Inity..."

# Create installation directory
sudo mkdir -p /usr/local/bin

# Copy executable
sudo cp inity /usr/local/bin/inity
sudo chmod +x /usr/local/bin/inity

echo "✅ Inity installed successfully!"
echo "Run 'inity --help' to get started"
