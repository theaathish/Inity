
Inity - Python Project Setup Tool
Developed by Aathish at Strucureo

Installation:
1. Extract the files
2. Run: chmod +x install.sh && ./install.sh
3. Or manually copy 'inity' to /usr/local/bin/

Usage:
inity create my-project
inity package search requests
inity --help for more commands
